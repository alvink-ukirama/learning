function display(value) {
  if (document.getElementById("result").value !== 0) {
    document.getElementById("clear").value = "C";
    if (document.getElementById("result").value == 0) {
      document.getElementById("result").value = "";
    }
    document.getElementById("result").value += value;
  }
}

function arithmatic(value) {
  i = value;
  document.getElementById("result").value = "";
}

function compute() {
  i = i += document.getElementById("result").value;
  var j = eval(i);
  document.getElementById("result").value = j;
}

function clr() {
  document.getElementById("clear").value = "AC";
  document.getElementById("result").value = 0;
}
